// This is a JavaScript file

$.ajax({
      url: "content/content.txt",
      cache: false,
      crossDomain: true,
      success: function(html){          
        var div = document.createElement("div");
        div.innerHTML = html;
        var chapters = div.querySelectorAll('.chapter');
        //alert(JSON.stringify(chapters[0].innerHTML));
        
      },
      error: function(html){
        alert('Fail: '+JSON.stringify(html));
      }
    });   
    
    
    
           
  //  ons.ready(function{ons.disableAutoStyling();});
    
    document.addEventListener("show", function(event){
        if(event.target.id=='page2') {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', "test_data.html", true);
            xhr.send();             
            xhr.onreadystatechange = processRequest;             
            function processRequest(e) {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);
                    document.getElementById('myText').innerHTML='Your ip is '+response.ip;
                }
            }
        }
    });
